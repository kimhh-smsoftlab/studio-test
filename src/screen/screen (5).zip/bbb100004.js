// [form:event ] OnFormInit  start...
form.OnFormInit=function(tagName, objData){
    grd_all.OnGetData(dataAll);
    gb_all.$html.show();
    gb_news.$html.hide();
    gb_gongsi.$html.hide();
    gb_dart.$html.hide();
    $('.tabtitle').css('border','none');
    $('#'+grd_all.id).css('border','none');
    $('#'+grd_all.id).addClass('pq-grid-row');
    $('#'+grd_news.id).css('border','none');
    $('#'+grd_news.id).addClass('pq-grid-row');
    $('#'+grd_gongsi.id).css('border','none');
    $('#'+grd_gongsi.id).addClass('pq-grid-row');
    $('#'+grd_dart.id).css('border','none');
    $('#'+grd_dart.id).addClass('pq-grid-row');
    
    $('.move').children().css('margin-bottom','3% !important');
    btn_all.OnClick();
}

// [grid:event ] OnCellClick  start...
grd_all.OnCellClick=function(rowData, rowIndx, dataIndx, colIndx){
    $('.hi5_formlink.news').show();
    $('.newsSize').hide();
};
// [grid:event ] OnCellClick  start...
grd_news.OnCellClick=function(rowData, rowIndx, dataIndx, colIndx){
    //var title = rowData["title"];
  //alert (title + '클릭');
    $('.hi5_formlink.news').show();
    $('.newsSize').hide();
};
// [grid:event ] OnCellClick  start...
grd_gongsi.OnCellClick=function(rowData, rowIndx, dataIndx, colIndx){
   /* var title = rowData["title"];
  alert (title + '클릭');*/
    $('.hi5_formlink.news').show();
    $('.newsSize').hide();
};
// [grid:event ] OnCellClick  start...
grd_dart.OnCellClick=function(rowData, rowIndx, dataIndx, colIndx){
    /*var title = rowData["title"];
  alert (title + '클릭');*/
    $('.hi5_formlink.news').show();
    $('.newsSize').hide();
};

// 모의 뉴스 데이터들
let dataAll = [
    { title: '[속보] 삼성전자 상장폐지', date: " 2020/12/31 14:13", journal : "연합뉴스", hname: "삼성전자"},
    { title: 'CU 매각 추진 실패', date: " 2020/12/31 14:13", journal : "연합뉴스", hname: "BGF"},
    { title: '검찰개혁 강조한 황운하 잠든채 발견', date: " 2020/12/31 14:13", journal : "연합뉴스", hname: "BGF"},
    { title: '환경부 장관 후보 사퇴 ', date: " 2020/12/31 14:13", journal : "연합뉴스", hname: "BGF"},
    { title: 'TSMC 파운드리 사업 철수', date: " 2020/12/31 14:13", journal : "연합뉴스", hname: "SK하이닉스"},
    { title: '[속보] 삼성전자 상장폐지', date: " 2020/12/31 14:13", journal : "연합뉴스", hname: "삼성전자"},
    { title: 'CU 매각 추진 실패', date: " 2020/12/31 14:13", journal : "연합뉴스", hname: "BGF"},
    { title: '검찰개혁 강조한 황운하 잠든채 발견', date: " 2020/12/31 14:13", journal : "연합뉴스", hname: "BGF"},
    { title: '환경부 장관 후보 사퇴 ', date: " 2020/12/31 14:13", journal : "연합뉴스", hname: "BGF"},
    { title: 'TSMC 파운드리 사업 철수', date: " 2020/12/31 14:13", journal : "연합뉴스", hname: "SK하이닉스"},
    { title: '검찰개혁 강조한 황운하 잠든채 발견', date: " 2020/12/31 14:13", journal : "연합뉴스", hname: "BGF"},
    { title: '환경부 장관 후보 사퇴 ', date: " 2020/12/31 14:13", journal : "연합뉴스", hname: "BGF"},
    { title: 'TSMC 파운드리 사업 철수', date: " 2020/12/31 14:13", journal : "연합뉴스", hname: "SK하이닉스"}
];

// [grid:event ] OnColumnRender  start...
grd_all.OnColumnRender=function(ui){
    let htmlText = 
    /*   타이틀   */  "<div><span style='font-weight:bold;font-size:16px;float:left;margin-left:10px;'>" + ui.rowData.title + "</span></br></div>"
    /*    날짜    */ +"<div><span style='font-size:13px;color:#c7c7c7;float:left;margin-left:10px;margin-right:20px;'>" + ui.rowData.date + "</span>"
    /*  관련종목  */ +"<span style='font-size:14px;color:#c7c7c7;float:left;margin-left:10px;'>" + ui.rowData.hname + "</span></div>";
    return {text : htmlText}; 
};

// 모의 뉴스 데이터들
let dataNews = [
    { title: '[속보] 삼성전자 상장폐지', date: " 2020/12/31 14:13", journal : "연합뉴스", hname: "삼성전자"},
    { title: 'CU 매각 추진 실패', date: " 2020/12/31 14:13", journal : "연합뉴스", hname: "BGF"},
    { title: '검찰개혁 강조한 황운하 잠든채 발견', date: " 2020/12/31 14:13", journal : "연합뉴스", },
    { title: '환경부 장관 후보 사퇴 ', date: " 2020/12/31 14:13", journal : "연합뉴스", },
    { title: 'TSMC 파운드리 사업 철수', date: " 2020/12/31 14:13", journal : "연합뉴스", hname: "SK하이닉스"},
    { title: '[속보] 삼성전자 상장폐지', date: " 2020/12/31 14:13", journal : "연합뉴스", hname: "삼성전자"},
    { title: 'CU 매각 추진 실패', date: " 2020/12/31 14:13", journal : "연합뉴스", hname: "BGF"},
    { title: '검찰개혁 강조한 황운하 잠든채 발견', date: " 2020/12/31 14:13", journal : "연합뉴스", },
    { title: '환경부 장관 후보 사퇴 ', date: " 2020/12/31 14:13", journal : "연합뉴스", },
    { title: 'TSMC 파운드리 사업 철수', date: " 2020/12/31 14:13", journal : "연합뉴스", hname: "SK하이닉스"}
];

// [grid:event ] OnColumnRender  start...
grd_news.OnColumnRender=function(ui){
    let htmlText = 
    /*   타이틀   */  "<div><span style='font-weight:bold;font-size:16px;float:left;margin-left:10px;'>" + ui.rowData.title + "</span></br></div>"
    /*    날짜    */ +"<div><span style='font-size:13px;color:#c7c7c7;float:left;margin-left:10px;margin-right:20px;'>" + ui.rowData.date + "</span>"
    /*  관련종목  */ +"<span style='font-size:14px;color:#c7c7c7;float:left;margin-left:10px;'>" + ui.rowData.hname + "</span></div>";
    return {text : htmlText}; 
};

// 모의 뉴스 데이터들
let dataGong = [
    { title: '[속보] 삼성전자 상장폐지', date: " 2020/12/31 14:13", journal : "연합뉴스", hname: "삼성전자"},
    { title: 'CU 매각 추진 실패', date: " 2020/12/31 14:13", journal : "연합뉴스", hname: "BGF"},
    { title: '검찰개혁 강조한 황운하 잠든채 발견', date: " 2020/12/31 14:13", journal : "연합뉴스", },
    { title: '환경부 장관 후보 사퇴 ', date: " 2020/12/31 14:13", journal : "연합뉴스", },
    { title: 'TSMC 파운드리 사업 철수', date: " 2020/12/31 14:13", journal : "연합뉴스", hname: "SK하이닉스"}
];

// [grid:event ] OnColumnRender  start...
grd_gongsi.OnColumnRender=function(ui){
    let htmlText = 
    /*   타이틀   */  "<div><span style='font-weight:bold;font-size:16px;float:left;margin-left:10px;'>" + ui.rowData.title + "</span></br></div>"
    /*    날짜    */ +"<div><span style='font-size:13px;color:#c7c7c7;float:left;margin-left:10px;margin-right:20px;'>" + ui.rowData.date + "</span>"
    /*  관련종목  */ +"<span style='font-size:14px;color:#c7c7c7;float:left;margin-left:10px;'>" + ui.rowData.hname + "</span></div>";
    return {text : htmlText}; 
};

// 모의 뉴스 데이터들
let dataDart = [
    { title: '[속보] 삼성전자 상장폐지', date: " 2020/12/31 14:13", journal : "연합뉴스", hname: "삼성전자"},
    { title: 'CU 매각 추진 실패', date: " 2020/12/31 14:13", journal : "연합뉴스", hname: "BGF"},
    { title: '검찰개혁 강조한 황운하 잠든채 발견', date: " 2020/12/31 14:13", journal : "연합뉴스", },
    { title: '환경부 장관 후보 사퇴 ', date: " 2020/12/31 14:13", journal : "연합뉴스", },
    { title: 'TSMC 파운드리 사업 철수', date: " 2020/12/31 14:13", journal : "연합뉴스", hname: "SK하이닉스"}
];

// [grid:event ] OnColumnRender  start...
grd_dart.OnColumnRender=function(ui){
    let htmlText = 
    /*   타이틀   */  "<div><span style='font-weight:bold;font-size:16px;float:left;margin-left:10px;'>" + ui.rowData.title + "</span></br></div>"
    /*    날짜    */ +"<div><span style='font-size:13px;color:#c7c7c7;float:left;margin-left:10px;margin-right:20px;'>" + ui.rowData.date + "</span>"
    /*  관련종목  */ +"<span style='font-size:14px;color:#c7c7c7;float:left;margin-left:10px;'>" + ui.rowData.hname + "</span></div>";
    return {text : htmlText}; 
};

// [button:event ] OnClick  start...
btn_all.OnClick=function(){
    $('#'+btn_news.id).removeClass('clickik');
    $('#'+btn_post.id).removeClass('clickik');
    $('#'+btn_dart.id).removeClass('clickik');
    $('#'+btn_all.id).addClass('clickik');
    gb_all.$html.show();
    gb_news.$html.hide();
    gb_gongsi.$html.hide();
    gb_dart.$html.hide();
    grd_all.OnGetData(dataAll);
};
// [button:event ] OnClick  start...
btn_news.OnClick=function(){
    $('#'+btn_all.id).removeClass('clickik');
    $('#'+btn_post.id).removeClass('clickik');
    $('#'+btn_dart.id).removeClass('clickik');
    $('#'+btn_news.id).addClass('clickik');
    gb_all.$html.hide();
    gb_news.$html.show();
    gb_gongsi.$html.hide();
    gb_dart.$html.hide();
    grd_news.OnGetData(dataNews);
};
// [button:event ] OnClick  start...
btn_post.OnClick=function(){
    $('#'+btn_all.id).removeClass('clickik');
    $('#'+btn_news.id).removeClass('clickik');
    $('#'+btn_dart.id).removeClass('clickik');
    $('#'+btn_post.id).addClass('clickik');
    gb_all.$html.hide();
    gb_news.$html.hide();
    gb_gongsi.$html.show();
    gb_dart.$html.hide();
    grd_gongsi.OnGetData(dataGong);
};
// [button:event ] OnClick  start...
btn_dart.OnClick=function(){
    $('#'+btn_all.id).removeClass('clickik');
    $('#'+btn_news.id).removeClass('clickik');
    $('#'+btn_post.id).removeClass('clickik');
    $('#'+btn_dart.id).addClass('clickik');
    gb_all.$html.hide();
    gb_news.$html.hide();
    gb_gongsi.$html.hide();
    gb_dart.$html.show();
    grd_dart.OnGetData(dataDart);
};