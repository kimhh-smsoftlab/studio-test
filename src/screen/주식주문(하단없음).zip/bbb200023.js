// [form:event ] OnFormInit  start...
form.OnFormInit=function(tagName, objData){
    $('#'+lb_1.id).css('border-bottom','1px solid #c2c2c2');
    btn_7.OnClick();
    $('.hi5_checkbox').attr('name','cost');
};

$('.hi5_checkbox').on('click',function(){
    $('input[type="checkbox"]').click(function(){
        if($(this).prop('checked')){
            $('input[type="checkbox"]').prop('checked',false);
            $(this).prop('checked',true);
        }
    });
});

// [button:event ] OnClick  start...
btn_1.OnClick=function(){
    $('.clickee').removeClass('clickee');
    $('#'+btn_1.id).addClass('clickee');
};

// [button:event ] OnClick  start...
btn_2.OnClick=function(){
    $('.clickee').removeClass('clickee');
    $('#'+btn_2.id).addClass('clickee');
};



// [button:event ] OnClick  start...
btn_7.OnClick=function(){
    $('.clickee').removeClass('clickee');
    $('#'+btn_7.id).addClass('clickee');
};

// [button:event ] OnClick  start...
btn_6.OnClick=function(){
    $('.hi5_formlink.subform').hide();
    $('.hi5_formlink.firstform').show();
    $('.hi5_groupbox.mainGroup').css('filter','none');
};