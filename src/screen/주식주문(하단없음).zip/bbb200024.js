// [form:event ] OnFormInit  start...
form.OnFormInit=function(tagName, objData){
    btn_4.OnClick();
    $('#'+st_1.id).css('border-bottom','1px solid #c2c2c2');
    $("#"+cb_2.id+" option:eq(10)").prop("selected", true);
    $("#"+cb_1.id).css('border-bottom','1px solid #c2c2c2');
    $("#"+cb_2.id).css('border-bottom','1px solid #c2c2c2');
    $("#"+cb_1.id).css('text-align-last','left');
    $("#"+cb_2.id).css('text-align-last','left');
};



// [button:event ] OnClick  start...
btn_4.OnClick=function(){
    $('.clickcss').removeClass('clickcss');
    $('#'+btn_4.id).addClass('clickcss');
};

// [button:event ] OnClick  start...
btn_5.OnClick=function(){
    $('.clickcss').removeClass('clickcss');
    $('#'+btn_5.id).addClass('clickcss');
};

// [button:event ] OnClick  start...
btn_2.OnClick=function(){
    $('.hi5_formlink.popUp').hide();
    $('.hi5_formlink.subform').css('filter','none');
};

// [button:event ] OnClick  start...
btn_1.OnClick=function(){
    $('.hi5_formlink.popUp').hide();
    $('.hi5_formlink.subform').css('filter','none');
};